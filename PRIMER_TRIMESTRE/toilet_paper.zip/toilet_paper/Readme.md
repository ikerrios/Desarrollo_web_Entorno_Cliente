

# ESTRUCTURA DEL PROJECTO EN CARPTEAS


Toilet-paper/

admin/
index.php
panel.php
index.css
panel.css
admin.js

config/
database.php
session.php
logout.php
function.js

login/
login.php
login.css
login.js

vistaUsuario/
perfil.php
perfil.css
panel_user.php
panel_user.css
panel_user.js